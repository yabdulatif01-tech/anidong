# AniDong — ishga tushirish va joylash

## Fayllar
- `index.html` — sayt (o'zgartirish shart emas)
- `server.py` — Flask server: katalog, admin kirish, yuklash, tahrirlash
- `requirements.txt`, `Procfile` — hosting uchun

Eski `data/catalog.json` endi **ishlatilmaydi** (server `data/library.json` bilan boshlanadi, u bo'sh). Eski animelar yo'q, hammasini admin qo'shadi.

## Kompyuterda sinash
```
pip install -r requirements.txt
python server.py        # http://127.0.0.1:5000
```

## Admin
- Istalgan anime **rasmiga 6 marta ketma-ket bosing** → parol → tahrirlash oynasi (rasm, nom, tur, reyting, joyi, qismlar, o'chirish, "Qism" qo'shish).
- Yuqoridagi ☁️ ikonka → yangi anime yoki yangi qism yuklash.
- O'zgarishlar serverda saqlanadi; saytni qayta deploy qilish yoki sahifani yangilash shart emas. Foydalanuvchilarda ~30 soniyada avtomatik yangilanadi.
- Standart parol — siz bergan uzun parol. Almashtirish: `ADMIN_PASSWORD` (oddiy matn) yoki `ADMIN_PASSWORD_SHA256` muhit o'zgaruvchisi.

## Muhit o'zgaruvchilari
| Nomi | Vazifasi |
|---|---|
| `DATA_DIR` | Ma'lumot va yuklangan fayllar papkasi. **Doimiy disk** bo'lishi shart |
| `ADMIN_PASSWORD` / `ADMIN_PASSWORD_SHA256` | Admin parol |
| `SECRET_KEY` | Token kaliti (ixtiyoriy) |
| `MAX_UPLOAD_MB` | Bitta fayl limiti (standart 2048) |

## Qayerga joylash
Yuklangan fayllar diskda turadi, shuning uchun **doimiy disk** kerak.
- **VPS (eng ishonchli):** har qanday Linux server. `pip install -r requirements.txt`, so'ng `gunicorn server:app --workers 1 --threads 8 --timeout 900 --bind 0.0.0.0:8000`, oldiga Caddy/nginx bilan HTTPS qo'ying.
- **Railway / Fly.io:** Volume ulab, `DATA_DIR` ni shu volume yo'liga qo'ying.
- **Render:** faqat **to'lovli Persistent Disk** bilan (`DATA_DIR=/var/data`). Bepul tarifda disk o'chib ketadi.
- **Vercel / Netlify:** mos emas (Flask va fayl yuklash uchun).
- Katta videolar uchun Cloudflare R2 ga yuklab, ochiq havolani "video havolasi" maydoniga qo'yish ham mumkin.

`--workers 1` ni o'zgartirmang: ma'lumotlar bitta JSON faylda.
