"""Tailwind CDN o'rniga statik CSS yaratadi (internet va Node shart emas).
Ishlatish:  python tools/mini_tailwind.py   (../index.html ichiga TW-START/TW-END orasiga yozadi)
index.html'ga yangi Tailwind klass qo'shsangiz, shu skriptni qayta ishga tushiring."""
import os, re, sys
PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'index.html')
COL = {'purple-300':'#d8b4fe','purple-400':'#c084fc','purple-500':'#a855f7','purple-600':'#9333ea','purple-900':'#581c87',
 'pink-500':'#ec4899','pink-600':'#db2777','pink-900':'#831843','gray-300':'#d1d5db','gray-400':'#9ca3af','gray-500':'#6b7280',
 'gray-900':'#111827','red-300':'#fca5a5','red-400':'#f87171','red-500':'#ef4444','emerald-400':'#34d399','amber-400':'#fbbf24',
 'white':'#ffffff','black':'#000000'}
PREFLIGHT = """*,::before,::after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}
html{line-height:1.5;-webkit-text-size-adjust:100%;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif}
body{margin:0;line-height:inherit}
h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}
a{color:inherit;text-decoration:inherit}
b,strong{font-weight:bolder}
button,input,optgroup,select,textarea{font-family:inherit;font-size:100%;font-weight:inherit;line-height:inherit;color:inherit;margin:0;padding:0}
button,select{text-transform:none}
button,[type=button],[type=submit]{-webkit-appearance:button;background-color:transparent;background-image:none}
blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}
ol,ul,menu{list-style:none;margin:0;padding:0}
input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}
button,[role=button]{cursor:pointer}
img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}
img,video{max-width:100%;height:auto}
[hidden]{display:none}"""
FIXED = {'block':'display:block','inline-block':'display:inline-block','inline':'display:inline','flex':'display:flex','grid':'display:grid','hidden':'display:none',
 'absolute':'position:absolute','fixed':'position:fixed','relative':'position:relative','sticky':'position:sticky',
 'flex-1':'flex:1 1 0%','flex-col':'flex-direction:column','flex-wrap':'flex-wrap:wrap','flex-grow':'flex-grow:1','shrink-0':'flex-shrink:0',
 'items-center':'align-items:center','justify-between':'justify-content:space-between','justify-center':'justify-content:center','content-start':'align-content:flex-start',
 'col-span-full':'grid-column:1 / -1','text-left':'text-align:left','text-center':'text-align:center','text-right':'text-align:right','uppercase':'text-transform:uppercase',
 'font-semibold':'font-weight:600','font-bold':'font-weight:700','font-extrabold':'font-weight:800','font-black':'font-weight:900',
 'leading-tight':'line-height:1.25','tracking-tight':'letter-spacing:-.025em','tracking-wider':'letter-spacing:.05em',
 'border':'border-width:1px','border-b':'border-bottom-width:1px','border-t':'border-top-width:1px',
 'rounded-md':'border-radius:.375rem','rounded-lg':'border-radius:.5rem','rounded-xl':'border-radius:.75rem','rounded-2xl':'border-radius:1rem','rounded-3xl':'border-radius:1.5rem','rounded-full':'border-radius:9999px',
 'overflow-hidden':'overflow:hidden','overflow-y-auto':'overflow-y:auto','cursor-pointer':'cursor:pointer','object-cover':'object-fit:cover','object-contain':'object-fit:contain',
 'opacity-30':'opacity:.3','mix-blend-overlay':'mix-blend-mode:overlay','backdrop-blur-md':'-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px)',
 'transition-all':'transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s','aspect-video':'aspect-ratio:16 / 9',
 'antialiased':'-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale','mt-auto':'margin-top:auto','mx-auto':'margin-left:auto;margin-right:auto',
 'bg-gradient-to-r':'background-image:linear-gradient(to right,var(--tw-gradient-stops))','bg-gradient-to-tr':'background-image:linear-gradient(to top right,var(--tw-gradient-stops))',
 'ring-2':'box-shadow:0 0 0 2px rgb(59 130 246 / .5)','outline-none':'outline:2px solid transparent;outline-offset:2px',
 'shadow-lg':'--tw-shadow:0 10px 15px -3px var(--tw-sc,rgb(0 0 0 / .1)),0 4px 6px -4px var(--tw-sc,rgb(0 0 0 / .1));box-shadow:var(--tw-shadow)'}
FS = {'xs':('.75rem','1rem'),'sm':('.875rem','1.25rem'),'base':('1rem','1.5rem'),'lg':('1.125rem','1.75rem'),'xl':('1.25rem','1.75rem'),'2xl':('1.5rem','2rem'),'3xl':('1.875rem','2.25rem'),'4xl':('2.25rem','2.5rem')}
MAXW = {'sm':'24rem','lg':'32rem','xl':'36rem','4xl':'56rem','7xl':'80rem'}
SIZE = {'w':'width','h':'height','min-w':'min-width','min-h':'min-height','max-w':'max-width','max-h':'max-height'}
SPC = {'p':['padding'],'px':['padding-left','padding-right'],'py':['padding-top','padding-bottom'],'pt':['padding-top'],'pb':['padding-bottom'],'pl':['padding-left'],'pr':['padding-right'],
 'm':['margin'],'mx':['margin-left','margin-right'],'my':['margin-top','margin-bottom'],'mt':['margin-top'],'mb':['margin-bottom'],'ml':['margin-left'],'mr':['margin-right']}
def sp(v):
    if v.startswith('['): return v[1:-1].replace('_',' ')
    if v == 'full': return '100%'
    if v == 'auto': return 'auto'
    if v == 'px': return '1px'
    m = re.fullmatch(r'(\d+)/(\d+)', v)
    if m: return f'{int(m[1])/int(m[2])*100:.6f}'.rstrip('0').rstrip('.') + '%'
    if re.fullmatch(r'\d+(\.\d+)?', v):
        n = float(v); return '0px' if n == 0 else f'{n*0.25:g}rem'
def color(tok):
    m = re.fullmatch(r'(.+?)(?:/(\d+))?', tok); name, a = m[1], m[2]
    base = name[1:-1] if name.startswith('[#') else COL.get(name)
    if not base or not base.startswith('#') or len(base) != 7: return None
    r, g, b = (int(base[i:i+2], 16) for i in (1, 3, 5)); return r, g, b, (int(a)/100 if a else None)
def rgb(c, a=None):
    a = c[3] if a is None else a
    return f'rgb({c[0]} {c[1]} {c[2]} / {a:g})' if a is not None else f'rgb({c[0]} {c[1]} {c[2]})'
def util(u):
    neg = u.startswith('-'); u = u[1:] if neg else u
    if not neg and u in FIXED: return FIXED[u]
    m = re.fullmatch(r'translate-([xy])-(.+)', u)
    if m and (v := sp(m[2])): return f'transform:translate{m[1].upper()}({"-" if neg else ""}{v})'
    m = re.fullmatch(r'(top|right|bottom|left)-(.+)', u)
    if m and (v := sp(m[2])): return f'{m[1]}:{"-" + v if neg and v != "0px" else v}'
    if u == 'inset-0': return 'inset:0px'
    if neg: return None
    m = re.fullmatch(r'z-(\d+|\[\d+\])', u)
    if m: return 'z-index:' + m[1].strip('[]')
    m = re.fullmatch(r'(min-w|min-h|max-w|max-h|w|h)-(.+)', u)
    if m:
        k, v = m[1], m[2]
        if v == 'screen': val = '100vh' if k.endswith('h') else '100vw'
        elif k == 'max-w' and v in MAXW: val = MAXW[v]
        else: val = sp(v)
        return f'{SIZE[k]}:{val}' if val else None
    m = re.fullmatch(r'(p|px|py|pt|pb|pl|pr|m|mx|my|mt|mb|ml|mr)-(.+)', u)
    if m and (v := sp(m[2])): return ';'.join(f'{p}:{v}' for p in SPC[m[1]])
    m = re.fullmatch(r'gap-(.+)', u)
    if m and (v := sp(m[1])): return 'gap:' + v
    m = re.fullmatch(r'grid-cols-(\d+)', u)
    if m: return f'grid-template-columns:repeat({m[1]},minmax(0,1fr))'
    m = re.fullmatch(r'col-span-(\d+)', u)
    if m: return f'grid-column:span {m[1]} / span {m[1]}'
    m = re.fullmatch(r'aspect-\[(.+)\]', u)
    if m: return 'aspect-ratio:' + m[1].replace('/', ' / ')
    m = re.fullmatch(r'text-(.+)', u)
    if m:
        t = m[1]
        if t in FS: return f'font-size:{FS[t][0]};line-height:{FS[t][1]}'
        if re.fullmatch(r'\[\d+px\]', t): return 'font-size:' + t[1:-1]
        if (c := color(t)): return 'color:' + rgb(c)
    m = re.fullmatch(r'bg-(.+)', u)
    if m and (c := color(m[1])): return 'background-color:' + rgb(c)
    m = re.fullmatch(r'border-(.+)', u)
    if m and (c := color(m[1])): return 'border-color:' + rgb(c)
    m = re.fullmatch(r'from-(.+)', u)
    if m and (c := color(m[1])): return f'--tw-gradient-from:{rgb(c)};--tw-gradient-to:{rgb(c, 0)};--tw-gradient-stops:var(--tw-gradient-from),var(--tw-gradient-to)'
    m = re.fullmatch(r'to-(.+)', u)
    if m and (c := color(m[1])): return '--tw-gradient-to:' + rgb(c)
    m = re.fullmatch(r'shadow-(.+)', u)
    if m and (c := color(m[1])): return '--tw-sc:' + rgb(c)
def esc(c): return re.sub(r'([^a-zA-Z0-9_-])', r'\\\1', c)
MEDIA = {'sm':640,'md':768,'lg':1024}
def build(text):
    toks = {t.rstrip('.:') for t in re.findall(r'[A-Za-z0-9_\-\[\]#/.:%]+', text)}
    groups = {None: [], 'sm': [], 'md': [], 'lg': []}
    for t in sorted(toks):
        *vs, u = t.split(':')
        if any(v not in ('hover', 'focus', 'selection', 'sm', 'md', 'lg') for v in vs): continue
        d = util(u)
        if not d: continue
        sel = '.' + esc(t); pseudo = 0
        for v in vs:
            if v in ('hover', 'focus'): sel += ':' + v; pseudo = 1
        if 'selection' in vs: sel = f'{sel} *::selection,{sel}::selection'; pseudo = 1
        media = next((v for v in vs if v in MEDIA), None)
        groups[media].append((pseudo, t, f'{sel}{{{d}}}'))
    out = [PREFLIGHT]
    for k in (None, 'sm', 'md', 'lg'):
        rules = '\n'.join(r for _, _, r in sorted(groups[k]))
        if rules: out.append(rules if k is None else f'@media (min-width:{MEDIA[k]}px){{\n{rules}\n}}')
    return '\n'.join(out)
if __name__ == '__main__':
    s = open(PATH, encoding='utf-8').read()
    s = re.sub(r'\s*<script src="https://cdn\.tailwindcss\.com"></script>', '', s)
    s = re.sub(r'\n?<style id="tw">.*?</style>', '', s, flags=re.S)
    css = build(s)
    i = s.index('</style>') + len('</style>')
    s = s[:i] + '\n  <style id="tw">\n' + css + '\n  </style>' + s[i:]
    open(PATH, 'w', encoding='utf-8').write(s)
    print('OK', len(css), 'bayt CSS')
